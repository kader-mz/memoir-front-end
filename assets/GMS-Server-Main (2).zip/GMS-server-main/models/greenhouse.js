const db = require("../util/database");

class Greenhouse {
    constructor({userId, greenhouseName, image, width, height, location, description}) {
        this.userId = userId;
        this.greenhouseName = greenhouseName;
        this.image = image;
        this.width = width;
        this.height = height;
        this.location = location;
        this.description = description;
    }
    
    static async getGreenhouseInformation(greenhouseId) {
        return await db.execute(`SELECT * FROM Greenhouse WHERE greenhouseId = ${greenhouseId} `);
    }
    
    static async getByGreenhouseName(name) {
        return await db.execute(`SELECT * FROM Greenhouse WHERE greenhouseName = '${name}' `);
    }

    static async getAllGreenhouses(userId) {
        return await db.execute(`
            SELECT WorkIn.role,  Greenhouse.greenhouseId,  Greenhouse.greenhouseName , Greenhouse.image, Greenhouse.ownerId
            FROM Greenhouse
            INNER JOIN WorkIn ON WorkIn.greenhouseId = Greenhouse.greenhouseId
            WHERE WorkIn.userId = ${userId} ;
        `);
    }

    static async createGreenhouse({userId, greenhouseName, width, height, location, description}) {
        const [[greenhouse]] = await Greenhouse.getByGreenhouseName(greenhouseName);
        if (greenhouse) {
            throw Error ('Greenhouse name already exists');
        }
        return await db.execute(`INSERT INTO Greenhouse (ownerId, greenhouseName, width, height, location, description) VALUES (?, ?, ?, ?, ?, ?)`,
        [userId, greenhouseName, width, height, location, description]); 
    }
}

module.exports = Greenhouse;







// #98BFDA
// #FEDE58
// #98D8A5
// #FE9898
// #FE98FE
// #FFFFFF

// #98BFDA
// #FEDE58
// #98D8A5
// #FE9898
// #FE98FE
// #FFFFFF

const db = require("../util/database");

class JoinGreenhouse {
  constructor() {}
  static async joinGreenhouse({ userId, greenhouseId, role }) {
    return await db.execute(
      `INSERT INTO WorkIn (userId, greenhouseId, role) VALUES (?, ?, ?)`,
      [userId, greenhouseId, role],
    );
  }

  static async getIdByEmail(email) {
    return await db.execute(
      `SELECT userId FROM User WHERE email = '${email}' ;`,
    );
  }

  static async getJoinRequestInformation({
    recieverId,
    greenhouseId,
    senderId,
    status,
  }) {
    return await db.execute(`
            SELECT User.userId As senderId, User.firstName, User.lastName, User.image , Greenhouse.greenhouseId, Greenhouse.greenhouseName, JoinGreenhouseRequest.role,  JoinGreenhouseRequest.status
            FROM User
            INNER JOIN JoinGreenhouseRequest ON User.userId = JoinGreenhouseRequest.senderId
            INNER JOIN Greenhouse ON JoinGreenhouseRequest.greenhouseId = Greenhouse.greenhouseId
            WHERE JoinGreenhouseRequest.recieverId = ${recieverId} AND JoinGreenhouseRequest.senderId = ${senderId} AND JoinGreenhouseRequest.greenhouseId = ${greenhouseId} AND JoinGreenhouseRequest.status = "${status}";
        `);
  }

  // static async getJoinRequestInformation({recieverId, greenhouseId, senderId, status}) {
  //     console.log({recieverId, greenhouseId, senderId})
  //     return await db.execute(`
  //         SELECT User.firstName, User.lastName, User.image ,Greenhouse.greenhouseName, JoinGreenhouseRequest.role, JoinGreenhouseRequest.status
  //         FROM User
  //         INNER JOIN JoinGreenhouseRequest ON User.userId = JoinGreenhouseRequest.senderId
  //         INNER JOIN Greenhouse ON JoinGreenhouseRequest.greenhouseId = Greenhouse.greenhouseId
  //         WHERE JoinGreenhouseRequest.recieverId = ${senderId} AND JoinGreenhouseRequest.senderId = ${recieverId} AND JoinGreenhouseRequest.greenhouseId = ${greenhouseId} AND JoinGreenhouseRequest.status = "${status}";
  //     `);
  // }

  static async getJoinGreenhouseBySRG({ senderId, greenhouseId, recieverId }) {
    return await db.execute(`
            SELECT WorkIn.userId, JoinGreenhouseRequest.recieverId
            FROM JoinGreenhouseRequest
            RIGHT JOIN WorkIn ON WorkIn.userId = JoinGreenhouseRequest.recieverId
            WHERE WorkIn.userId = ${recieverId} OR JoinGreenhouseRequest.senderId = ${senderId} AND JoinGreenhouseRequest.recieverId = ${recieverId} AND  JoinGreenhouseRequest.greenhouseId = ${greenhouseId} ;
        `);
  }

  static async setJoinGreenhouseRequest({
    senderId,
    greenhouseId,
    email,
    role,
  }) {
    const [[{ userId }]] = await JoinGreenhouse.getIdByEmail(email);
    if (userId == undefined) {
      throw Error("user email doesn't exist");
    }
    const [[request]] = await JoinGreenhouse.getJoinGreenhouseBySRG({
      senderId,
      recieverId: userId,
      greenhouseId,
    });
    console.log(request);
    if (request == undefined) {
      await db.execute(
        `INSERT INTO JoinGreenhouseRequest (senderId, recieverId, greenhouseId, role) VALUES (?, ?, ?, ?); `,
        [senderId, userId, greenhouseId, role],
      );
      return userId;
    } else {
      if (request.userId) {
        throw Error("user alredy work in this greenhouse");
      }
      throw Error("request alredy send");
    }
  }

  static async setRefuseJoinGreenhouseRequest({
    senderId,
    recieverId,
    greenhouseId,
  }) {
    return await db.execute(`
            UPDATE JoinGreenhouseRequest
            SET status = "reject", senderId = ${recieverId}, recieverId = ${senderId}, seen = false 
            WHERE senderId = ${senderId} AND recieverId = ${recieverId} AND greenhouseId = ${greenhouseId};
        `);
  }

  static async setAcceptuseJoinGreenhouseRequest({
    senderId,
    recieverId,
    greenhouseId,
  }) {
    return await db.execute(`
            UPDATE JoinGreenhouseRequest
            SET status = "accept", senderId = ${recieverId}, recieverId = ${senderId}, seen = false 
            WHERE senderId = ${senderId} AND recieverId = ${recieverId} AND greenhouseId = ${greenhouseId};
        `);
  }
}

module.exports = JoinGreenhouse;

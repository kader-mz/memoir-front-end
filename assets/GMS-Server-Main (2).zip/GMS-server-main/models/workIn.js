const db  = require("../util/database");

class WorkIn {
    constructor({userId, greenhouseId, role}) {
        this.userId = userId;
        this.greenhouseId = greenhouseId;
        this.role = role;
    }
    
}

module.exports = WorkIn;
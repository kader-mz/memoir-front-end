const bcrypt = require("bcrypt");
const db = require("../util/database");

class User {
    constructor ({firstName, lastName, email, password}) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
    }
    
    static async getEmail(email) {
        return await db.execute(`SELECT email FROM User WHERE email = '${email}' `);
    }
    static async getID(email) {
        return await db.execute(`SELECT userId FROM User WHERE email = '${email}' `);
    }
    
    static async getByEmail(email) {
        return await db.execute(`SELECT * FROM User WHERE email = '${email}' `);
    }
    
    static async login(email, password) {
        const [[user]] = await User.getByEmail(email);
        if(user == undefined) {
            throw Error("Incorrect email");
        }
        const match = await bcrypt.compare(password, user.password);
        if(!match) {
            throw Error("Incorrect password");
        }
        return user;
    }

    static async signup({firstName, lastName, email, password}) {
        const [[existEmail]] = await User.getEmail(email);
        if(existEmail) {
            throw Error("email alredy taken");
        }
        const salt = await bcrypt.genSalt();
        const hash = await bcrypt.hash(password, salt);
        return await db.execute(`INSERT INTO User (firstName, lastName, email, password) VALUES (?, ?, ?, ?); ` ,
        [firstName, lastName, email, hash]); 
    }

    static async connecting ({userId}){
        return await db.execute(`
            SELECT User.userId As senderId, User.firstName, User.lastName, User.image , Greenhouse.greenhouseId, Greenhouse.greenhouseName, JoinGreenhouseRequest.role, JoinGreenhouseRequest.status
            FROM User
            INNER JOIN JoinGreenhouseRequest ON User.userId = JoinGreenhouseRequest.senderId
            INNER JOIN Greenhouse ON JoinGreenhouseRequest.greenhouseId = Greenhouse.greenhouseId
            WHERE JoinGreenhouseRequest.recieverId = ${userId}  AND JoinGreenhouseRequest.seen = false;
        `);
    }

    static async makeSeen (data) {
        return db.execute(`
            UPDATE JoinGreenhouseRequest 
            set JoinGreenhouseRequest.seen = true
            WHERE JoinGreenhouseRequest.recieverId = ${data} AND JoinGreenhouseRequest.seen = flase;
        `);
    }
    
    static async deleteNote ({senderId, recieverId, greenhouseId}) {
        console.log({senderId, recieverId, greenhouseId})
        return db.execute(`
            DELETE FROM JoinGreenhouseRequest 
            WHERE JoinGreenhouseRequest.recieverId = ${recieverId} AND JoinGreenhouseRequest.senderId = ${senderId} AND JoinGreenhouseRequest.greenhouseId = ${greenhouseId};
        `);
    }
}









module.exports = User;  
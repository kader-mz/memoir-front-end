const db = require("../util/database");

class Task {
    constructor({snderId, geenhouseId, recieverId, task}) {
        this.snderId = snderId;
        this.recieverId = recieverId;
        this.geenhouseId = geenhouseId;
        this.task = task;
    }
    static async insertTask({senderId, greenhouseId, recieverId, task}){
        try{
            return await db.execute(`INSERT INTO Task (senderId, recieverId, greenhouseId, task) VALUES (?, ?, ?, ?); ` ,
            [senderId, recieverId, greenhouseId, task]);
        }catch(error){
            throw Error(error)
        }
    }
}

module.exports = Task;
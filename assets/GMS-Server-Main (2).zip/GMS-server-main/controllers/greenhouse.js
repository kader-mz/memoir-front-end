const Greenhouse = require("../models/greenhouse");

const createGreebhouse = async (req, res) => {
    try {
        const {userId, greenhouseName, width, height, location, description} = req.body;
        await Greenhouse.createGreenhouse({ userId, greenhouseName,  width, height, location, description });
        res.status(200).json({ message: "greenhouse create succssufuly" });
    }catch(error) {
        return res.status(400).json(error.message);
    }
}

const getAllGreenhouse = async (req, res) => {
    try { 
        const {userId} =  req.query
        const [data] = await Greenhouse.getAllGreenhouses(userId)
        res.status(200).json(data);
    } catch (error){
        return res.status(400).json(error.message);
    }
}

const getGreenhouseById = async (req, res) => {
    const {greenhouseId} = req.query
    const [[greenhouse]] = await Greenhouse.getGreenhouseInformation(greenhouseId);
    return res.json(greenhouse);
}

module.exports = {createGreebhouse, getAllGreenhouse, getGreenhouseById};
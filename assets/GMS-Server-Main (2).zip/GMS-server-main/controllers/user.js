const User = require("../models/user");
const jwt = require("jsonwebtoken");

const createTkoken = (id) => {
    return jwt.sign({id}, "jskomdhsqxKMLJIDxXEZXQSXLMKZAKEPOASZAKXJIZE", {expiresIn: "1w"})
}

const signup = async (req, res ) => {
    try{
        const {firstName, lastName, email, password} = req.body;
        await User.signup({firstName, lastName, email, password});
        const [[user]] = await User.getByEmail(email);
        const {userId, image} = user;
        const token = createTkoken(userId);
        res.cookie('myCookie', `{user: ${JSON.stringify({...userId})}}`, {
            domain: 'http://localhost:5173',
        });
        return res.status(200).json({userId, firstName, lastName, image, token});
    }catch(error){
        return res.status(400).json(error.message);
    }
}
    
const login = async (req, res) => {
    try {
        const {email, password} = req.query;
        const user = await User.login(email, password);
        const {userId, firstName, lastName, image} = user;
        const token = createTkoken(userId);
        res.cookie('myCookie', `{user: ${JSON.stringify({...userId})}}`, {
            domain: 'http://localhost:5173',
        });
        return res.status(200).json({userId, firstName, lastName, image, token});
    }catch (error){
        return res.status(400).json(error.message);
    }
    
}

const connecting = async ({socket, userId}) => {
    try{
        const [data] = await User.connecting({userId})
        socket.emit("connecting", data)
    }catch(error){
        console.log(error.message)
    }
}

const makeSeen = async (data) => {
    try{
        await User.makeSeen(data)
    }catch(error){
        console.log("error")
    }
}
const deleteNote = async (data) => {
    try{
        console.log(data)
        await User.deleteNote({...data})
    }catch(error){
        console.log(error.message)
    }
}

module.exports = {signup, login, connecting, makeSeen, deleteNote};
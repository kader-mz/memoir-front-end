const Task = require("../models/task");
const sendTask = async (socketIo, data) => {
    console.log(data)
    // await Task.insertTask(data);
    const recieverId = socketIo.getRecieverId(data.recieverId);
    if(recieverId){
        socketIo.io.to(recieverId).emit("task", {data})
    }
}

module.exports = {sendTask};

const JoinGreenhouse = require("../models/joinGreenhouse");
// const Task = require("../models/workIn");
const sendJoinGreenhouseRequest = async (socketIo, data) => {
    try{
        const {greenhouseId , email, senderId, role} = data
        const recieverId =  await JoinGreenhouse.setJoinGreenhouseRequest({senderId, email, greenhouseId, role})
        const socketRecieverId = socketIo.getRecieverId(recieverId);
        if(socketRecieverId){
            const [data] = await JoinGreenhouse.getJoinRequestInformation({greenhouseId, senderId, recieverId, status: "wating"})
            socketIo.io.to(socketRecieverId).emit("notification", data)
        }
    }catch(error){
        console.log(error.message)
        // socketIo.io.to(socketRecieverId).emit("join-greenhouse-request", data)
    }
}
const refuseJoinGreenhouseRequest = async (socketIo, data)=>{
    try{
        const {senderId, recieverId, greenhouseId} = data;
        console.log(data);
        await JoinGreenhouse.setRefuseJoinGreenhouseRequest({senderId, recieverId, greenhouseId});
        const socketRecieverId = socketIo.getRecieverId(senderId);
        if(socketRecieverId){
            const [data] = await JoinGreenhouse.getJoinRequestInformation({greenhouseId, senderId: recieverId, recieverId: senderId, status: "reject"});
            socketIo.io.to(socketRecieverId).emit("notification", data)
        }
    }catch(error){
        console.log(error.message)
    }
}

const acceptJoinGreenhouseRequest = async (socketIo, data)=>{
    try{
        const {senderId, recieverId, greenhouseId} = data;
        await JoinGreenhouse.setAcceptuseJoinGreenhouseRequest({senderId, recieverId, greenhouseId});
        const socketRecieverId = socketIo.getRecieverId(senderId);
        if(socketRecieverId){
            const [data] = await JoinGreenhouse.getJoinRequestInformation({greenhouseId, senderId: recieverId, recieverId: senderId, status: "accept"});
            console.log("on sned",data)
            socketIo.io.to(socketRecieverId).emit("notification", data)
        }
    }catch(error){
        console.log(error.message)
    }
}

module.exports = {sendJoinGreenhouseRequest, refuseJoinGreenhouseRequest, acceptJoinGreenhouseRequest};
const express = require("express");
const { app, httpServer } = require("./socket/socket");
const bodyParser = require("body-parser");
const cors = require("cors");
// Routers
const userRouter = require("./routers/user");
const greenhouseRouter = require("./routers/greenhouse");

app.use(
  cors({
    origin: ["http://localhost:5173", "http:// 192.168.40.149:5173"],
    credentials: true,
  }),
);
app.use(express.static("public/images"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use("/user", userRouter);
app.use("/greenhouse", greenhouseRouter);

httpServer.listen(3000,"192.168.40.149", () => {
  console.log("server running");
});

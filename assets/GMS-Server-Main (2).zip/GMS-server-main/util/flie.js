const fs = require('fs');
const delFile = (filePath) => {
    fs.unlink(filePath, (err) => {
        if (err) {
            console.error('Error deleting file:', err);
            return;
        }
        console.log('File has been successfully deleted');
    });
}

const copyFile = (sourcePath, destinationPath) => {
    fs.readFile(sourcePath, (err, data) => {
        if (err) {
            console.error(err);
            return;
        }
        fs.writeFile(destinationPath, data, (err) => {
            if (err) {
                console.error(err);
                return;
            }
            console.log('Image copied successfully!');
        });
    });
}

module.exports = {delFile, copyFile};

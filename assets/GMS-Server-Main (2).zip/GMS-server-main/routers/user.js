
const express = require("express");
const { signup, login } = require("../controllers/user");
const route = express.Router();


route.post("/signup", signup);

route.get("/login", login)

module.exports =  route ;



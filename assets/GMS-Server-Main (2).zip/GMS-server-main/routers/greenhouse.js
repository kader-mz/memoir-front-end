const express = require("express");
const { createGreebhouse, getAllGreenhouse, getGreenhouseById } = require("../controllers/greenhouse");


const route = express.Router();


route.post("/createGreebhouse", createGreebhouse);
route.get("/getAllGreenhouse", getAllGreenhouse);
route.get("/getGreenhouseById", getGreenhouseById);





module.exports =  route ;

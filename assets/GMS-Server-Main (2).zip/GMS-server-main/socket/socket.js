const http = require("http");
const express = require("express");
const {Server} = require("socket.io");


// event
const {sendTask} = require("../controllers/task");
const {sendJoinGreenhouseRequest, refuseJoinGreenhouseRequest, acceptJoinGreenhouseRequest} = require("../controllers/joinGreenhouse");
const {connecting, makeSeen, deleteNote} = require("../controllers/user");

const app = express();
const httpServer = http.createServer(app);

const socketIo = {
    io: new Function(),
    userSocketMap: {},
    getRecieverId: (userId) => {
        return socketIo.userSocketMap[userId];
    }
}

socketIo.io = new Server(httpServer, {
    cors: {
        origin: [
            "http://localhost:5173",
            "http://192.168.23.46:5173"
        ]
    }
});

socketIo.io.on("connection", (socket)=>{
    const {userId} =  socket.handshake.query
    if(userId){
        socketIo.userSocketMap[userId] = socket.id;
    }

    connecting({socket, userId});
    console.log(socketIo.userSocketMap);
    socket.on("task", (data) => sendTask(socketIo, data));
    socket.on("join-greenhouse-request", (data) => {sendJoinGreenhouseRequest(socketIo, data)});
    socket.on("refuse-join-greenhouse-request", (data) => {refuseJoinGreenhouseRequest(socketIo, data)});
    socket.on("accept-join-greenhouse-request", (data) => {acceptJoinGreenhouseRequest(socketIo, data)});
    socket.on("make-seen", (data) => makeSeen(data))
    socket.on("delete-note", (data) => deleteNote(data))
    
    socket.on("disconnection", (data) => {
        delete socketIo.userSocketMap[data]
        socketIo.io.emit("disconnection", data)
        console.log("Disconnected: ", socketIo.userSocketMap);
    });
})

module.exports = {app, httpServer};







